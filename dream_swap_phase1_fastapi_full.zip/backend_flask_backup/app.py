from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import csv
import os

app = Flask(__name__)
CORS(app)

CSV_FILE = "/mnt/data/dream_swap_interface/backend/claims.csv"

# Initialize CSV if not exists
if not os.path.isfile(CSV_FILE):
    with open(CSV_FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["wallet", "amount", "status"])

@app.route("/swap", methods=["POST"])
def swap():
    data = request.get_json()
    wallet = data.get("wallet")
    amount = data.get("amount")
    with open(CSV_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([wallet, amount, "pending"])
    return jsonify({"message": "Swap request received. Status: pending"})

@app.route("/claims", methods=["GET"])
def get_claims():
    with open(CSV_FILE, newline="") as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        return jsonify([row for row in reader])

@app.route("/download-csv", methods=["GET"])
def download_csv():
    return send_file(CSV_FILE, as_attachment=True)

if __name__ == "__main__":
    app.run(port=5000)
