# Arbitrage Commander Phase 1

**Core Build Includes:**
- Simple Arbitrage Bot scanning BTC-USD, ETH-USD, LTC-USD
- Adaptive 5s scan interval with 30s backoff on 429
- 0.3% minimum profit threshold after fees
- Simulated trade execution
- Full console logging
