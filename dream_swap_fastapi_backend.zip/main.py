
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import csv
import os
from fastapi.responses import FileResponse
from typing import List

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

CSV_FILE = "/mnt/data/dream_swap_interface/backend/claims.csv"

# Initialize CSV
if not os.path.isfile(CSV_FILE):
    with open(CSV_FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["wallet", "amount", "status"])

class SwapRequest(BaseModel):
    wallet: str
    amount: str

@app.post("/swap")
def receive_swap(request: SwapRequest):
    with open(CSV_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([request.wallet, request.amount, "pending"])
    return {"message": "Swap request received. Status: pending"}

@app.get("/claims", response_model=List[List[str]])
def get_claims():
    with open(CSV_FILE, newline="") as f:
        reader = csv.reader(f)
        next(reader)  # Skip header
        return [row for row in reader]

@app.get("/download-csv")
def download_csv():
    return FileResponse(CSV_FILE, media_type='text/csv', filename="claims.csv")
